char* str_state = "";
char* str_light_id = "";
char _msg[25];

void set_light(String,String);
void set_light_str(int);
void set_light_str(String light_id);

void enviarHumedad(void);
void enviarTemperatura(void);
void PublishSerializeObject(int, String);

void transform_incoming_msg(String incoming_msg) {

  String device_id = "";
  String light_id = "";
  String state = "";
  int str_length = incoming_msg.length();
  char incoming_msg_c[str_length + 1];
  strcpy(incoming_msg_c, incoming_msg.c_str());
  int count = 0;
  
  char * partes = strtok(incoming_msg_c, "|");
  
   while( partes != NULL ) {
      //Serial.print("partes: " + String(partes));
      if(count == 0) {
        device_id = String(partes);
      } else if(count == 1) {
        light_id = String(partes);
      } else if (count == 2) {
        state = String(partes);
      }

      partes = strtok(NULL, "|");
      count++;
   }

   Serial.print("device_id: " + device_id);
   Serial.print("light_id: " + light_id);
   Serial.print("state: " + state);

   //if(device_id.toInt() == DEVICE_ID) //Device ID validation
    set_light(light_id,state);
}

void set_light(String  str_light_id, String str_state) {

  int state = LOW;
  
  if (str_state == "ON") {
    state = HIGH;
  }

  String str = String(str_light_id) + ":"+ String(state);
  digitalWrite(str_light_id.toInt(), state);
  Serial.print(str);
}

void set_light_str(String light_id){

  switch(light_id.toInt()) {

    case 13:
      str_light_id = "YELLOW_LIGHT";
      break;
    
    case 4:
      str_light_id = "BLUE_LIGHT";
      break;

    case 5:
      str_light_id = "BLUE_LIGHT_OTHER";
      break;

    case 15:
      str_light_id = "RED_LIGHT";
      break;

    case 21:
      str_light_id = "GREEN_LIGHT";
      break;

    case 23:
      str_light_id = "WHITE_LIGHT";
      break;
      
    default:
      str_light_id = "NO_LIGHT";
      break;
  }
}

void interrupcionHumedadTemperatura(){

  periodicTickerHumedad.attach_ms(DHT_SENDING_TIME, enviarHumedad);
  periodicTickerTemperatura.attach_ms(DHT_SENDING_TIME, enviarTemperatura);
    
  //onceTicker.once_ms(10000, oncePrint);
}

void enviarHumedad() {
  float h = dht.readHumidity();
  if (isnan(h)) {
    PublishSerializeObject(0, "Fallo al leer el sensor de humedad");
  }
  String json;
  char jsonBuffer[512];
  StaticJsonDocument<300> doc;
  doc["tipoSensor"] = "humedad";
  doc["lectura"] = h;
  doc["tipoLectura"] = F("%");
  serializeJson(doc, jsonBuffer);
  String message = "Enviando Humedad: ";
  message.concat(h);
  message.concat("\n");
  Serial.print(message);
  client.publish(PUBLICACION_TOPICO_HUMEDAD, jsonBuffer);
}

void enviarTemperatura() {
  float t = dht.readTemperature();
  if (isnan(t)) {
    PublishSerializeObject(0, "Fallo al leer el sensor de temperatura");
  }
  String json;
  char jsonBuffer[512];

  StaticJsonDocument<300> doc;
  doc["tipoSensor"] = "temperatura";
  doc["lectura"] = t;
  doc["tipoLectura"] = F("°C");
  serializeJson(doc, jsonBuffer);
  String message = "Enviando Temperatura: ";
  message.concat(t);
  message.concat("\n");
  Serial.print(message);
  client.publish(PUBLICACION_TOPICO_TEMPERATURA, jsonBuffer);
}

void PublishSerializeObject(int tipoMensaje, String mensaje)
{
  String json;
  char jsonBuffer[512];
  StaticJsonDocument<300> doc;
  String tipo;
  if (tipoMensaje == 0) {
    tipo = "error";
  } else if (tipoMensaje == 1) {
    tipo = "advertencia";
  }
  doc["tipoMensaje"] = tipo;
  doc["mensaje"] = mensaje;
  serializeJson(doc, jsonBuffer);
  client.publish(PUBLICACION_TOPICO_ERROR, jsonBuffer);
}
